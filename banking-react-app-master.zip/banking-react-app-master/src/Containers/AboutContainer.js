import React from "react";
import AboutUsComp from "../Components/AboutUs/index";

class AboutContainer extends React.Component {
  render() {
    return (
      <>
        <AboutUsComp />
      </>
    );
  }
}

export default AboutContainer;
