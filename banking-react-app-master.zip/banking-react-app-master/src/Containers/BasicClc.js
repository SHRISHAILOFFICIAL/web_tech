import React from "react";
import BasicClcIndexCom from "../Components/Calculator/BasicClc/index";

class BasicClcContainer extends React.Component {
  render() {
    return (
      <>
        <BasicClcIndexCom />
      </>
    );
  }
}

export default BasicClcContainer;
