import React from "react";
import ContatUsIndexComp from '../Components/ContactUs/index';

class ContactContainer extends React.Component {
  render() {
    return (
      <ContatUsIndexComp />
    );
  }
}

export default ContactContainer;
