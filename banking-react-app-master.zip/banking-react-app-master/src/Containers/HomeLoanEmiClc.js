import React from "react";
import HomeLoanIndex from "../Components/Calculator/HomeLoanClc/index";

class HomeLoanEmiClcContainer extends React.Component {
  render() {
    return (
      <>
        <HomeLoanIndex />
      </>
    );
  }
}

export default HomeLoanEmiClcContainer;
