import React from "react";

import IncomeTaxClcComp from "../Components/Calculator/IncomeTaxClc/index";

class IncomeTaxClcContainer extends React.Component {
    render() {
        return (
            <>
                <IncomeTaxClcComp />
            </>
        );
    }
}

export default IncomeTaxClcContainer;
