import React from "react";

import SimpleInterestClcComp from "../Components/Calculator/SimpleInterestClc/index";

class SimpleInterstClcContainer extends React.Component {
  render() {
    return (
      <>
        <SimpleInterestClcComp />
      </>
    );
  }
}

export default SimpleInterstClcContainer;
