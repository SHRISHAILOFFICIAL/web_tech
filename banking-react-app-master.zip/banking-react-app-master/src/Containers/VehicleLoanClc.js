import React from "react";
import VehicleLoanIndex from "../Components/Calculator/VehicleLoanClc/index";

class VehicleLoanClc extends React.Component {
  render() {
    return <VehicleLoanIndex />;
  }
}

export default VehicleLoanClc;
